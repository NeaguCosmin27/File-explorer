package Listeners;

public interface ControlsAreaListener {
    public void getHierarchicalPath(String hierarchicalPath);
}
