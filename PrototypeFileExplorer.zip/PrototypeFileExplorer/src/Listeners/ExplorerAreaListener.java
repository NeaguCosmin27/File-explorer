package Listeners;

public interface ExplorerAreaListener {
     public void getSelectedPath(String fileHierarchicalPath);
     public void getSelectedFileName(String selectedFileName);
}
