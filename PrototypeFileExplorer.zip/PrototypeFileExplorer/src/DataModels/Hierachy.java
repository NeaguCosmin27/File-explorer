package DataModels;

public class Hierachy {

}
